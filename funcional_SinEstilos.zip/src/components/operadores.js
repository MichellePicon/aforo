import React, { Component } from 'react';
import firebase from '../firebase';
import { Link } from 'react-router-dom';

class operadores extends Component{

    constructor(){
        super();
        this.ref= firebase.firestore().collection('operadores');
        this.unsubscribe= null;
        this.state = {
            Operadores:[]
          };
    }

    onChange = (e) => {
        const state = this.state
        state[e.target.name] = e.target.value;
        this.setState(state);
        console.log(this.operador);
      }

      getOperadores = (querySnapshot) => {

        const Operadores=[];
    
            querySnapshot.forEach((doc) => {
              const { Nombre} = doc.data();
              Operadores.push({
                key: doc.id,
                Nombre
              });
            });
            this.setState({
              Operadores
            });
          }
    
      componentDidMount(){
        this.unsubscribe=this.ref.onSnapshot(this.getOperadores);
      }

    render(){
        return(
            <div>
              <header>
                <Link className="App-link" to="/">Volver</Link>
                </header>
                <h3 class="panel-title">
                    Seleccione su nombre
                </h3>
                <div class="form-group" onChange={Nombre => this.onChange(Nombre)}>
                    <select name="Nombre">
                    <option value="" selected="selected">  </option>
                    {this.state.Operadores.map(Valor =>
                      <option  value={Valor.Nombre}>{Valor.Nombre}</option>)}
                  </select>
                  </div>
                  <Link className="btn btn-primary" to="/aforoinfo">Ok</Link>            
            </div>
        )
    }
}

export default operadores;