import React, { Component } from 'react';
import { Link } from 'react-router-dom';

class MenuCoord extends Component{
    render(){
        return(
            <div>
                <header>
                <Link className="App-link" to="/">Volver</Link>
                </header>
              <Link className="App-link" to="/RegistroOp">Registrar Operario</Link>
              <Link className="App-link" to="/resultados">Datos</Link>
              <Link className="App-link" to="/Personalizacion">Personalización</Link>
              <Link className="App-link" to="/">Cerrar Sesión</Link>
            </div>
        );
    }
}

export default MenuCoord;