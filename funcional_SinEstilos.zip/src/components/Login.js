import React, { Component } from 'react';
import { Link } from 'react-router-dom';

class Login extends Component{
  render(){
    return(
      <div>
        <header>
                <Link className="App-link" to="/">Volver</Link>
                </header>
        <form >

        <div class="container">
        <label for="uname"><b>Usuario</b></label>
          <div>
          
          <input type="text" placeholder="aaa@example.com" name="uname" required/>

          </div>
          <label for="psw"><b>Contraseña</b></label>
          <div>
          
          <input type="password" placeholder="Ingrese su Contraseña" name="psw" required/>

          </div>
          
          <Link class="btn btn-primary" to="/MenuCoord">Continuar</Link>

        </div>

      </form>
      </div>
    );
  }
}

export default Login;