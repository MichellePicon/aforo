import React, { Component } from 'react';
import DatePicker from 'react-datepicker';
import firebase from '../firebase';
import { Link } from 'react-router-dom';
import 'react-datepicker/dist/react-datepicker.css';


class aforoinfo extends Component {
    constructor(){
        super();
        this.ref= firebase.firestore().collection('aforoinfo');
        this.state = {
            clima: '',
            fecha: new Date(),
            obs:''
          };
    }
        
    onChange = (e) => {
        const state = this.state
        state[e.target.name] = e.target.value;
        this.setState(state);
      }
    
      handleChange = date => {
        this.setState({
          fecha: date
        });
      };

      onSubmit = (e) => {
        e.preventDefault();
    
        const { clima, fecha, obs } = this.state;
    
        this.ref.add({
          clima,
          fecha,
          obs
        }).then((docRef) => {
          this.setState({
            clima: '',
            fecha: new Date(),
            obs:''
          });
          this.props.history.push("/aforocont")
        })
        .catch((error) => {
          console.error("Error", error);
        });
      }
    
  
  render() {
    const { clima, fecha, obs } = this.state;
    return (
        <div>
          <header>
                <Link className="App-link" to="/operadores">Volver</Link>
                </header>
            <div class="panel-heading">
                <h3 class="panel-title">
                    Datos de Aforo
                </h3>
            </div>
            <div class="panel-body">
                <form onSubmit={this.onSubmit}>
                    
                    <div class="form-group" onChange={clima => this.onChange(clima)}>
                        <h4 class="panel-title">
                            Clima
                        </h4>
                        <label>Lluvia</label>
                        <input type="radio" id="clima" name="clima" value="Lluvia"></input>
                        <label>Nublado</label>
                        <input type="radio" id="clima" name="clima" value="Nublado"></input>
                        <label>Soleado</label>
                        <input type="radio" id="clima" name="clima" value="Soleado"></input>
                        <label>Granizo</label>
                        <input type="radio" id="clima" name="clima" value="Granizo"></input>
                        <label>Tormenta</label>
                        <input type="radio" id="clima" name="clima" value="Tormenta"></input>
                    </div>
                    <div class="form-group">
                        <h4 class="panel-title">
                            Fecha y Hora
                        </h4>
                            <DatePicker
                                selected={this.state.fecha}
                                onChange={this.handleChange}
                                showTimeSelect
                                timeFormat="HH:mm"
                                timeIntervals={15}
                                dateFormat="Pp"
                            />
                    </div>
                    <div>
                    <label for="obs">Observaciones</label>
                  <input 
                    type="text" 
                    name="obs" value={obs} 
                    class="form-control"
                    onChange={(e) => {
                      this.setState({obs: e.target.value});
                      }} 
                      placeholder="¿Algo adicional que nos quieras contar?" 
                  />
                    </div>
                    
                    
                    <button type="submit" class="btn btn-primary" align="right">Ok</button>
                </form>
                
            </div>
        </div>
        
      );
  }
}

export default aforoinfo;
