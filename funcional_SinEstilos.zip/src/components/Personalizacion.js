import React, { Component } from 'react';
import { Link } from 'react-router-dom';

class Personalizacion extends Component{
    render(){
        return(
            <div>
                <header>
                <Link className="App-link" to="/MenuCoord">Volver</Link>
                </header>
                <h1>PERSONALIZACIÓN</h1>
                <form >
                <div>
                <div class="container">
                <label><b>Vehículos de Carga</b></label>
                <div>
                    <input class="form-check-input" type="radio"></input>
                    <label>Liviano de Carga</label>
                </div>
                <div>
                    <input class="form-check-input" type="radio"></input>
                    <label>Camión de Carga C2-C3</label>
                </div>
                <div>
                    <input class="form-check-input" type="radio"></input>
                    <label>Camión de carga pesada</label>
                </div>
                
                <label><b>Vehículos de Pasajeros</b></label>
                <div>
                    <input class="form-check-input" type="radio"></input>
                    <label>Camioneta</label>
                </div>
                <div>
                    <input class="form-check-input" type="radio"></input>
                    <label>Automóviles</label>
                </div>
                <div>
                    <input class="form-check-input" type="radio"></input>
                    <label>Microbus</label>
                </div>
                <div>
                    <input class="form-check-input" type="radio"></input>
                    <label>Motocicletas</label>
                </div>
                <div>
                    <input class="form-check-input" type="radio"></input>
                    <label>Bus</label>
                </div>

                <label><b>Equipo Pesado</b></label>
                <div>
                    <input class="form-check-input" type="radio"></input>
                    <label>Vehículos de Construcción</label>
                </div>
                <div>
                    <input class="form-check-input" type="radio"></input>
                    <label>vehículos Agrícolas</label>
                </div>

                <label><b>Otros</b></label>
                <div>
                    <input class="form-check-input" type="radio"></input>
                    <label>Remolques y/o trailers</label>
                </div>
                </div>
                
                <div>
                    <div>
                    <label>Nombre de la vía</label>
                    </div>
                
                  <input type="text" />
                  <div>
                  <label>Periodo</label>
                  </div>
                  
                  <div>
                      <div>
                      <label>Tiempo</label>
                      </div>
                  
                  <input type="text" />
                  <div>
                      <label>Descanso</label>
                      </div>
                  <input type="text" />
                  </div>
                  
                </div>

                <Link class="btn btn-primary" to="/MenuCoord">Guardar</Link>

                </div>

                </form>
            </div>
        );
    }
}

export default Personalizacion;