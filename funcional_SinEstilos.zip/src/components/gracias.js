import React, { Component } from 'react';
import { Link } from 'react-router-dom';
import 'react-datepicker/dist/react-datepicker.css';

class gracias extends Component{
    render(){
        return(
            <div>
                <h2>
                    ¡Tu conteo ha finalizado con éxito!
                </h2>
                <Link className="App-link" to="/">Volver a la página principal</Link>
            </div>
        )
    }
}

export default gracias;