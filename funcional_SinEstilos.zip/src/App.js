import React from 'react';
import './App.css';
import { Link } from 'react-router-dom';
import Login from './components/Login'

function App() {
  return (
    <div className="App">
      
      <header className="App-header">
        <Link className="App-link" to="/operadores">Operario</Link>
        <Link className="App-link" to="/Login">Coordinador</Link>
      </header>
      
    </div>
  );
}

export default App;
